<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Index</title>
</head>

<body>
	
	<div id="main-parent">
		<div id="header"><img style="border: 2px black dotted" src="resource/5.png" alt="header_image;" ></div>
		<div id="menubar" style="width: auto;height: 50px;border: 2px black dotted">
		
			<table border="2px" width="100%">
			<tr style="height: 50px">
				<td style="text-align: center"> <a href="index.php"> Home</a></td>
				<td style="text-align: center"> <a href="index.php"> About Us</a></td>
				<td style="text-align: center"> <a href="index.php"> Contact</a></td>
				<td style="text-align: center"> <a href="login.php"> Log in</a></td>
				<td style="text-align: center"><a href="signup.php"> Sign Up</a></td>
			</tr>
		</table>
		</div>
		<div id="content"  ><img width="100%" alt="body img" src="resource/body1.jpg" >
		</div>
		<div id="footer"  style="border: 2px black dotted; height:50px; text-align: center">
			<footer>&copy; Copyright 2018 <a href="#">Faisal,Milon,Shatu &amp; Kaiyum</a></footer>

		</div>
	</div>
</body>
</html>
